For at køre programmet skal man åbne PasswordManager.pde

OBS!!!
Programmet er skrevet og testet med Processing 3.5.4

programmet kræver ControlP5 og java.awt biblioteker

java.awt er installeret standart med processing IDE